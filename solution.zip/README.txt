fferrar4
tnguy228

                       ASSIGNEMENT 4

 CESCO - did object file type, instruction set, endianess, and entirety of section header

 TAYLOR - did symbol table, error handling, readability