/*
 * README file describing contributions
 * CSF Assignment 4
 * F. Ferrara
 * fferrar4@jhu.edu
 * T. Nguyen
 * tnguy228@jhu.edu
*/


 CESCO - did object file type, instruction set, endianess, and entirety of section header

 TAYLOR - did symbol table, error handling, readability
